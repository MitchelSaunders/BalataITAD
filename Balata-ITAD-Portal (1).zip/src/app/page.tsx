// ITAD Portal Mockup - Balata Data
<your ITAD portal code here from the canvas>
